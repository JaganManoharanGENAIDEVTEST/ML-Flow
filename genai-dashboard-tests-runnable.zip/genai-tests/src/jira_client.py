"""
Pulls a User Story from Jira, and posts test results back onto the ticket.

Mock mode reads from a local fixture so the framework is runnable without
Jira credentials. Live mode uses the Jira REST API v3
(https://developer.atlassian.com/cloud/jira/platform/rest/v3/).
"""
import json
from pathlib import Path

from src import config

_FIXTURE_PATH = Path(__file__).parent.parent / "fixtures" / "jira_user_story.json"


class JiraClient:
    def get_user_story(self, ticket_key: str) -> dict:
        if config.is_mock():
            stories = json.loads(_FIXTURE_PATH.read_text())
            story = stories.get(ticket_key)
            if story is None:
                raise KeyError(f"No mock fixture found for ticket {ticket_key}")
            return story

        return self._get_live(ticket_key)

    def _get_live(self, ticket_key: str) -> dict:
        try:
            import requests
            from requests.auth import HTTPBasicAuth
        except ImportError as e:
            raise RuntimeError(
                "FRAMEWORK_MODE=live requires `pip install requests` (see requirements-live.txt)"
            ) from e

        url = f"{config.JIRA_BASE_URL}/rest/api/3/issue/{ticket_key}"
        resp = requests.get(
            url,
            auth=HTTPBasicAuth(config.JIRA_EMAIL, config.JIRA_API_TOKEN),
            headers={"Accept": "application/json"},
            timeout=15,
        )
        resp.raise_for_status()
        data = resp.json()
        fields = data["fields"]
        return {
            "key": data["key"],
            "summary": fields.get("summary", ""),
            "description": fields.get("description", ""),
            # Acceptance criteria commonly live in a custom field in Jira Cloud —
            # replace "customfield_XXXXX" with your project's actual field id.
            "acceptance_criteria": fields.get("customfield_XXXXX", []),
        }

    def post_test_results_comment(self, ticket_key: str, summary: str) -> None:
        if config.is_mock():
            print(f"[mock] Would post to {ticket_key}:\n{summary}")
            return

        try:
            import requests
            from requests.auth import HTTPBasicAuth
        except ImportError as e:
            raise RuntimeError(
                "FRAMEWORK_MODE=live requires `pip install requests` (see requirements-live.txt)"
            ) from e

        url = f"{config.JIRA_BASE_URL}/rest/api/3/issue/{ticket_key}/comment"
        body = {"body": {"type": "doc", "version": 1, "content": [
            {"type": "paragraph", "content": [{"type": "text", "text": summary}]}
        ]}}
        resp = requests.post(
            url,
            json=body,
            auth=HTTPBasicAuth(config.JIRA_EMAIL, config.JIRA_API_TOKEN),
            headers={"Accept": "application/json", "Content-Type": "application/json"},
            timeout=15,
        )
        resp.raise_for_status()
