"""
Minimal incremental-refresh simulator used to test streaming / auto-refresh
behavior: only new rows are pulled on each refresh, with no duplicates and
no gaps — the properties that matter most for a live dashboard.
"""
from dataclasses import dataclass, field


@dataclass
class DataStream:
    """Simulates a source table that grows over time, as new transactions,
    shipments, or visits land."""

    _rows: list = field(default_factory=list)
    _next_id: int = 1

    def push(self, payload: dict) -> dict:
        row = {"id": self._next_id, **payload}
        self._rows.append(row)
        self._next_id += 1
        return row

    def all_rows(self) -> list:
        return list(self._rows)


class IncrementalRefresher:
    """Pulls only rows newer than the last seen id — mirrors an incremental
    Power BI / dataset refresh against a growing source table."""

    def __init__(self, stream: DataStream):
        self.stream = stream
        self._last_seen_id = 0
        self.materialized: list = []

    def refresh(self) -> list:
        new_rows = [r for r in self.stream.all_rows() if r["id"] > self._last_seen_id]
        self.materialized.extend(new_rows)
        if new_rows:
            self._last_seen_id = max(r["id"] for r in new_rows)
        return new_rows
