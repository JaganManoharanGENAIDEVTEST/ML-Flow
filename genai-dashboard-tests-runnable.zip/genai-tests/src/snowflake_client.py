"""
Snowflake client with two modes:

- mock: runs SQL against an in-memory SQLite database seeded with sample
  Banking / Logistics / Healthcare data, so the whole framework is runnable
  without live Snowflake credentials.
- live: uses the real `snowflake-connector-python` package.

Switch modes with FRAMEWORK_MODE=live in .env (see .env.example).
"""
import sqlite3
from typing import Any

from src import config

_SEED_SQL = """
CREATE TABLE transactions (
    id INTEGER PRIMARY KEY,
    branch TEXT,
    region TEXT,
    amount REAL,
    txn_date TEXT,
    category TEXT
);

CREATE TABLE shipments (
    id INTEGER PRIMARY KEY,
    origin TEXT,
    destination TEXT,
    status TEXT,
    ship_date TEXT,
    delay_days INTEGER
);

CREATE TABLE patient_visits (
    id INTEGER PRIMARY KEY,
    department TEXT,
    visit_type TEXT,
    visit_date TEXT,
    wait_minutes INTEGER
);
"""

_SEED_DATA = {
    "transactions": [
        # id, branch, region, amount, txn_date, category
        (1, "Chennai Central", "South", 125000.0, "2026-04-05", "Deposit"),
        (2, "Chennai Central", "South", 84000.0, "2026-05-14", "Withdrawal"),
        (3, "Chennai Central", "South", 61000.0, "2026-06-20", "Deposit"),
        (4, "Bangalore MG Road", "South", 143000.0, "2026-04-11", "Deposit"),
        (5, "Bangalore MG Road", "South", 97000.0, "2026-05-02", "Loan Payment"),
        (6, "Bangalore MG Road", "South", 52000.0, "2026-06-18", "Withdrawal"),
        (7, "Mumbai Andheri", "West", 210000.0, "2026-04-22", "Deposit"),
        (8, "Mumbai Andheri", "West", 175000.0, "2026-05-29", "Deposit"),
        (9, "Mumbai Andheri", "West", 88000.0, "2026-06-09", "Loan Payment"),
        (10, "Delhi CP", "North", 132000.0, "2026-04-30", "Withdrawal"),
        (11, "Delhi CP", "North", 121000.0, "2026-05-17", "Deposit"),
        (12, "Delhi CP", "North", 69000.0, "2026-06-25", "Deposit"),
    ],
    "shipments": [
        (1, "Chennai", "Coimbatore", "Delivered", "2026-06-01", 0),
        (2, "Chennai", "Bangalore", "Delivered", "2026-06-03", 1),
        (3, "Mumbai", "Pune", "Delayed", "2026-06-05", 3),
        (4, "Mumbai", "Delhi", "Delivered", "2026-06-07", 0),
        (5, "Delhi", "Jaipur", "In Transit", "2026-06-10", 0),
        (6, "Chennai", "Hyderabad", "Delayed", "2026-06-12", 2),
    ],
    "patient_visits": [
        (1, "Cardiology", "Consultation", "2026-06-01", 22),
        (2, "Cardiology", "Follow-up", "2026-06-02", 15),
        (3, "Orthopedics", "Consultation", "2026-06-03", 30),
        (4, "Orthopedics", "Surgery Prep", "2026-06-04", 45),
        (5, "Pediatrics", "Consultation", "2026-06-05", 10),
        (6, "Pediatrics", "Vaccination", "2026-06-06", 8),
    ],
}


class SnowflakeClient:
    """Thin wrapper so tests don't care whether they're hitting SQLite or Snowflake."""

    def __init__(self):
        self.mock = config.is_mock()
        if self.mock:
            self._conn = sqlite3.connect(":memory:")
            self._conn.row_factory = sqlite3.Row
            self._seed()
        else:
            self._conn = self._connect_live()

    def _seed(self):
        cur = self._conn.cursor()
        cur.executescript(_SEED_SQL)
        for table, rows in _SEED_DATA.items():
            placeholders = ",".join(["?"] * len(rows[0]))
            cur.executemany(f"INSERT INTO {table} VALUES ({placeholders})", rows)
        self._conn.commit()

    def _connect_live(self):
        try:
            import snowflake.connector
        except ImportError as e:
            raise RuntimeError(
                "FRAMEWORK_MODE=live requires `pip install snowflake-connector-python` "
                "(see requirements-live.txt)"
            ) from e
        return snowflake.connector.connect(
            account=config.SNOWFLAKE_ACCOUNT,
            user=config.SNOWFLAKE_USER,
            password=config.SNOWFLAKE_PASSWORD,
            warehouse=config.SNOWFLAKE_WAREHOUSE,
            database=config.SNOWFLAKE_DATABASE,
            schema=config.SNOWFLAKE_SCHEMA,
        )

    def run_query(self, sql: str) -> list[dict[str, Any]]:
        """Runs SQL and returns rows as a list of dicts, regardless of backend."""
        cur = self._conn.cursor()
        cur.execute(sql)
        if self.mock:
            return [dict(row) for row in cur.fetchall()]
        columns = [c[0] for c in cur.description]
        return [dict(zip(columns, row)) for row in cur.fetchall()]

    def close(self):
        self._conn.close()
