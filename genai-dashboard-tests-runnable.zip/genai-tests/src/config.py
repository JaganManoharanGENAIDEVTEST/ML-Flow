"""
Central configuration for the framework, loaded from environment variables
(and a local .env file if present via python-dotenv).

FRAMEWORK_MODE=mock (default) runs everything against local fixtures and an
in-memory SQLite database, so the whole suite works with zero external
credentials. Set FRAMEWORK_MODE=live and fill in the values below once you
point this at the real Snowflake / Power BI / Jira / LLM services.
"""
import os

from dotenv import load_dotenv

load_dotenv()

MODE = os.getenv("FRAMEWORK_MODE", "mock").lower()

# --- Snowflake (live mode only) ---
SNOWFLAKE_ACCOUNT = os.getenv("SNOWFLAKE_ACCOUNT")
SNOWFLAKE_USER = os.getenv("SNOWFLAKE_USER")
SNOWFLAKE_PASSWORD = os.getenv("SNOWFLAKE_PASSWORD")
SNOWFLAKE_WAREHOUSE = os.getenv("SNOWFLAKE_WAREHOUSE")
SNOWFLAKE_DATABASE = os.getenv("SNOWFLAKE_DATABASE")
SNOWFLAKE_SCHEMA = os.getenv("SNOWFLAKE_SCHEMA")

# --- Power BI (live mode only) ---
POWERBI_WORKSPACE_ID = os.getenv("POWERBI_WORKSPACE_ID")
POWERBI_CLIENT_ID = os.getenv("POWERBI_CLIENT_ID")
POWERBI_CLIENT_SECRET = os.getenv("POWERBI_CLIENT_SECRET")
POWERBI_TENANT_ID = os.getenv("POWERBI_TENANT_ID")

# --- Jira (live mode only) ---
JIRA_BASE_URL = os.getenv("JIRA_BASE_URL")
JIRA_EMAIL = os.getenv("JIRA_EMAIL")
JIRA_API_TOKEN = os.getenv("JIRA_API_TOKEN")

# --- LLM used for requirement-intake test generation (live mode only) ---
LLM_PROVIDER = os.getenv("LLM_PROVIDER", "mock").lower()
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY")

# --- Functional layer tuning ---
ALERT_SUPPRESSION_WINDOW_SECONDS = int(os.getenv("ALERT_SUPPRESSION_WINDOW_SECONDS", "300"))
DATA_FRESHNESS_SLA_SECONDS = int(os.getenv("DATA_FRESHNESS_SLA_SECONDS", "60"))


def is_mock() -> bool:
    return MODE != "live"
