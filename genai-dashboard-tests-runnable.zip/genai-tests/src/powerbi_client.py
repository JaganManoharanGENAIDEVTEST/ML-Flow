"""
Stand-in for the Power BI embed the real dashboard would show.

In mock mode, renders a minimal static HTML page from the same table data
the agent produced, so Playwright can validate rendering / tooltip / data
consistency without needing a live embedded Power BI report.

In live mode, replace `render_dashboard` with calls to the Power BI REST API
(https://learn.microsoft.com/rest/api/power-bi/) using
POWERBI_CLIENT_ID / POWERBI_CLIENT_SECRET / POWERBI_TENANT_ID, and return the
report's embed URL instead of a local file path.
"""
from pathlib import Path

from src import config

_TEMPLATE_PATH = Path(__file__).parent.parent / "mock_data" / "dashboard_template.html"


class PowerBIClient:
    def render_dashboard(self, title: str, table: list, value_key: str, label_key: str) -> str:
        """Mock mode: builds a static HTML page and returns its file path.
        Live mode: would return an embed URL from the Power BI REST API."""
        if not config.is_mock():
            raise NotImplementedError("Wire this up to the Power BI REST API for live mode.")

        max_value = max((row[value_key] for row in table), default=1) or 1
        bars = []
        for row in table:
            height_pct = round((row[value_key] / max_value) * 100, 1)
            bars.append(
                f'<div class="bar" style="height:{height_pct}%" '
                f'data-value="{row[value_key]}" title="{row[label_key]}: {row[value_key]}">'
                f'<div class="bar-label">{row[label_key]}</div></div>'
            )

        header_row = "".join(f"<th>{k}</th>" for k in table[0].keys()) if table else ""
        body_rows = "".join(
            "<tr>" + "".join(f'<td class="cell-{k}">{v}</td>' for k, v in row.items()) + "</tr>"
            for row in table
        )

        html = _TEMPLATE_PATH.read_text().format(
            title=title,
            bars="\n".join(bars),
            header_row=header_row,
            body_rows=body_rows,
        )

        out_path = Path("/tmp/mock_dashboard_render.html")
        out_path.write_text(html)
        return str(out_path)
