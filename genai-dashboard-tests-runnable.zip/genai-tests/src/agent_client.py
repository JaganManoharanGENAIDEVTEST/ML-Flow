"""
Stand-in for the actual GenAI application under test (NL prompt -> SQL ->
result table).

In mock mode, prompts are resolved to SQL via a deterministic lookup table.
This simulates a well-trained agent so the rest of the framework — which
diffs the agent's answer against an independently-run Snowflake query — has
something realistic to validate against, without needing a live LLM.

In live mode, replace `ask()`'s body with a real call to your agent's API
endpoint (e.g. `requests.post(AGENT_ENDPOINT, json={"prompt": prompt})`).
"""
from dataclasses import dataclass
from typing import Optional

from src import config
from src.snowflake_client import SnowflakeClient

# Deterministic "what a good agent should generate" for each known prompt.
# Keyed by a normalized (lowercased, whitespace-collapsed) prompt string.
PROMPT_SQL_MAP = {
    "total transaction amount by branch": """
        SELECT branch, SUM(amount) AS total_amount
        FROM transactions
        GROUP BY branch
        ORDER BY branch
    """,
    "total transaction amount by branch in q2 2026": """
        SELECT branch, SUM(amount) AS total_amount
        FROM transactions
        WHERE txn_date BETWEEN '2026-04-01' AND '2026-06-30'
        GROUP BY branch
        ORDER BY branch
    """,
    "top 3 branches by deposit amount": """
        SELECT branch, SUM(amount) AS total_deposits
        FROM transactions
        WHERE category = 'Deposit'
        GROUP BY branch
        ORDER BY total_deposits DESC
        LIMIT 3
    """,
    "delayed shipments by origin": """
        SELECT origin, COUNT(*) AS delayed_count
        FROM shipments
        WHERE status = 'Delayed'
        GROUP BY origin
    """,
    "average wait time by department": """
        SELECT department, AVG(wait_minutes) AS avg_wait
        FROM patient_visits
        GROUP BY department
        ORDER BY avg_wait DESC
    """,
}

# Prompts containing any of these should be safely refused rather than executed.
_ADVERSARIAL_MARKERS = ["drop table", "delete from", "; --", "ignore previous instructions"]


@dataclass
class AgentResponse:
    prompt: str
    sql: Optional[str]
    table: list
    refused: bool
    refusal_reason: Optional[str] = None


class AgentClient:
    def __init__(self):
        self.sf = SnowflakeClient()

    @staticmethod
    def _normalize(prompt: str) -> str:
        return " ".join(prompt.lower().strip().split())

    def ask(self, prompt: str) -> AgentResponse:
        normalized = self._normalize(prompt)

        for marker in _ADVERSARIAL_MARKERS:
            if marker in normalized:
                return AgentResponse(
                    prompt=prompt, sql=None, table=[], refused=True,
                    refusal_reason="Prompt contains a disallowed SQL operation; request refused.",
                )

        if config.is_mock():
            sql = PROMPT_SQL_MAP.get(normalized)
            if sql is None:
                return AgentResponse(
                    prompt=prompt, sql=None, table=[], refused=True,
                    refusal_reason="No matching intent found for this prompt.",
                )
            table = self.sf.run_query(sql)
            return AgentResponse(prompt=prompt, sql=sql, table=table, refused=False)

        raise NotImplementedError(
            "Wire this up to your real agent's API endpoint for live mode."
        )

    def close(self):
        self.sf.close()
