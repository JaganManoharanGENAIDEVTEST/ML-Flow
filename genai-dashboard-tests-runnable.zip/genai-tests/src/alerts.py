"""
Minimal alert engine used to demonstrate threshold, delivery, and
de-duplication testing without needing a live notification service.

In live mode, swap `NotificationCapture.send` for a real call to your
email / Slack / Teams webhook, and keep asserting on the payload it builds.
"""
import time
from dataclasses import dataclass
from typing import Optional


@dataclass
class Alert:
    metric: str
    value: float
    threshold: float
    message: str


class NotificationCapture:
    """Stands in for an email/Slack/Teams webhook — just records what was sent,
    so tests can assert on exact payload content rather than trusting a
    'sent successfully' flag."""

    def __init__(self):
        self.sent: list[Alert] = []

    def send(self, alert: Alert):
        self.sent.append(alert)


class AlertManager:
    def __init__(self, notifier: NotificationCapture, suppression_seconds: int = 300):
        self.notifier = notifier
        self.suppression_seconds = suppression_seconds
        self._last_fired_at: dict[str, float] = {}

    def evaluate(
        self, metric: str, value: float, threshold: float, now: Optional[float] = None
    ) -> bool:
        """Returns True if an alert was actually sent (i.e. not suppressed)."""
        now = time.time() if now is None else now

        if value <= threshold:
            return False  # condition not breached

        last = self._last_fired_at.get(metric)
        if last is not None and (now - last) < self.suppression_seconds:
            return False  # duplicate within the suppression window

        alert = Alert(
            metric=metric,
            value=value,
            threshold=threshold,
            message=f"{metric} breached threshold: {value} > {threshold}",
        )
        self.notifier.send(alert)
        self._last_fired_at[metric] = now
        return True
