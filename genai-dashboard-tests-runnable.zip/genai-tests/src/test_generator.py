"""
Turns a Jira User Story into test cases and NL test prompts — the
"requirement intake" layer described in the framework overview document.

Mock mode uses a deterministic, rule-based generator so the framework runs
without an LLM API key. Live mode calls a real LLM to do the same job with
actual language understanding — implement `_generate_live` with your
provider of choice (Anthropic, OpenAI, etc.) once you're ready to switch
LLM_PROVIDER away from "mock" in .env.
"""
import re

from src import config


def generate_tests_from_story(story: dict) -> dict:
    if config.is_mock() or config.LLM_PROVIDER == "mock":
        return _generate_mock(story)
    return _generate_live(story)


def _generate_mock(story: dict) -> dict:
    """Rule-based stand-in for an LLM reviewing the story. For each
    acceptance criterion, drafts a test case tagged positive/negative. Also
    derives a couple of representative NL test prompts from the story
    summary, in the same phrasing a real user would type."""
    test_cases = []
    for i, criterion in enumerate(story.get("acceptance_criteria", []), start=1):
        is_negative = bool(re.search(r"\bno\b|\bnot\b|\bwithout\b", criterion.lower()))
        test_cases.append({
            "id": f"{story['key']}-TC{i}",
            "criterion": criterion,
            "test_type": "negative" if is_negative else "positive",
        })

    summary = story.get("summary", "")
    base_prompt = re.sub(
        r"^(branch manager wants|as an?\s.*?,\s*i want (to see |to view )?)",
        "",
        summary.lower(),
    ).strip()
    if not base_prompt:
        base_prompt = summary.lower()

    prompts = [base_prompt, f"{base_prompt} in q2 2026"]

    return {
        "ticket": story["key"],
        "test_cases": test_cases,
        "prompts": prompts,
    }


def _generate_live(story: dict) -> dict:
    raise NotImplementedError(
        "Implement a real LLM call here (e.g. Anthropic/OpenAI), prompting it "
        "with the story's description and acceptance criteria, and requesting "
        "JSON-formatted test cases and NL prompts back. Parse and return them "
        "in the same {'ticket', 'test_cases', 'prompts'} shape as _generate_mock."
    )
