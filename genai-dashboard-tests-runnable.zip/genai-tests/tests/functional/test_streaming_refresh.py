from src.streaming import DataStream, IncrementalRefresher


def test_incremental_refresh_pulls_only_new_rows():
    stream = DataStream()
    refresher = IncrementalRefresher(stream)

    stream.push({"branch": "Chennai Central", "amount": 1000})
    stream.push({"branch": "Bangalore MG Road", "amount": 2000})

    first_batch = refresher.refresh()
    assert len(first_batch) == 2

    stream.push({"branch": "Mumbai Andheri", "amount": 3000})
    second_batch = refresher.refresh()

    assert len(second_batch) == 1
    assert second_batch[0]["branch"] == "Mumbai Andheri"


def test_incremental_refresh_has_no_duplicates_or_gaps():
    stream = DataStream()
    refresher = IncrementalRefresher(stream)

    for i in range(5):
        stream.push({"branch": f"Branch-{i}", "amount": i * 100})

    refresher.refresh()
    stream.push({"branch": "Branch-5", "amount": 500})
    refresher.refresh()

    ids = [r["id"] for r in refresher.materialized]
    assert ids == sorted(set(ids)), "Duplicate or out-of-order rows detected"
    assert ids == list(range(1, 7)), "Gap detected in materialized rows"


def test_refresh_with_no_new_data_returns_empty_batch():
    stream = DataStream()
    refresher = IncrementalRefresher(stream)
    stream.push({"branch": "Chennai Central", "amount": 1000})

    refresher.refresh()
    empty_batch = refresher.refresh()

    assert empty_batch == []
