from src.alerts import AlertManager, NotificationCapture


def test_no_alert_below_threshold():
    notifier = NotificationCapture()
    mgr = AlertManager(notifier)
    fired = mgr.evaluate("failed_txn_rate", value=2.0, threshold=5.0)
    assert fired is False
    assert notifier.sent == []


def test_alert_fires_exactly_once_above_threshold():
    notifier = NotificationCapture()
    mgr = AlertManager(notifier)
    fired = mgr.evaluate("failed_txn_rate", value=7.5, threshold=5.0, now=1000.0)
    assert fired is True
    assert len(notifier.sent) == 1
    assert notifier.sent[0].value == 7.5
    assert notifier.sent[0].message == "failed_txn_rate breached threshold: 7.5 > 5.0"


def test_duplicate_alert_suppressed_within_window():
    notifier = NotificationCapture()
    mgr = AlertManager(notifier, suppression_seconds=300)
    mgr.evaluate("failed_txn_rate", value=7.5, threshold=5.0, now=1000.0)
    fired_again = mgr.evaluate("failed_txn_rate", value=8.0, threshold=5.0, now=1100.0)
    assert fired_again is False
    assert len(notifier.sent) == 1  # still only one


def test_alert_fires_again_after_suppression_window():
    notifier = NotificationCapture()
    mgr = AlertManager(notifier, suppression_seconds=300)
    mgr.evaluate("failed_txn_rate", value=7.5, threshold=5.0, now=1000.0)
    fired_again = mgr.evaluate("failed_txn_rate", value=8.0, threshold=5.0, now=1400.0)
    assert fired_again is True
    assert len(notifier.sent) == 2
