"""
Validates the core promise of the pipeline: whatever table the agent
returns for a prompt must match what you get by running an independently
written SQL query against the same data — i.e. the agent's SQL generation
is actually correct, not just plausible-looking.
"""
import pytest

from src.agent_client import AgentClient

# Prompt -> SQL written independently of the agent's own generation logic,
# used purely as a ground truth to diff against.
PROMPTS_WITH_INDEPENDENT_SQL = [
    (
        "total transaction amount by branch",
        """
        SELECT branch, SUM(amount) AS total_amount
        FROM transactions
        GROUP BY branch
        ORDER BY branch
        """,
    ),
    (
        "top 3 branches by deposit amount",
        """
        SELECT branch, SUM(amount) AS total_deposits
        FROM transactions
        WHERE category = 'Deposit'
        GROUP BY branch
        ORDER BY total_deposits DESC
        LIMIT 3
        """,
    ),
    (
        "average wait time by department",
        """
        SELECT department, AVG(wait_minutes) AS avg_wait
        FROM patient_visits
        GROUP BY department
        ORDER BY avg_wait DESC
        """,
    ),
]


@pytest.fixture(scope="module")
def agent():
    client = AgentClient()
    yield client
    client.close()


@pytest.mark.parametrize("prompt,independent_sql", PROMPTS_WITH_INDEPENDENT_SQL)
def test_agent_table_matches_independent_snowflake_query(agent, prompt, independent_sql):
    response = agent.ask(prompt)
    assert not response.refused, f"Agent unexpectedly refused: {response.refusal_reason}"
    assert response.sql, "Agent did not return generated SQL"

    # A fresh, independent connection — never reuses the agent's own connection —
    # so this is a genuine external check, not comparing a query against itself.
    independent = AgentClient().sf
    expected = independent.run_query(independent_sql)
    independent.close()

    assert response.table == expected, (
        f"Agent table does not match independent Snowflake query for prompt: {prompt!r}"
    )


def test_agent_returns_expected_columns_for_known_prompt(agent):
    response = agent.ask("Total transaction amount by branch")
    assert response.table, "Expected at least one row"
    assert set(response.table[0].keys()) == {"branch", "total_amount"}
