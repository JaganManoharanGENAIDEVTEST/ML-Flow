"""
Tracks accuracy of the agent's SQL generation against the golden prompt
bank, logged to MLflow so drift is visible run over run. Open the MLflow UI
from the project root with:

    mlflow ui --backend-store-uri sqlite:///mlflow.db

and browse to the "genai-dashboard-eval" experiment.
"""
import json
from pathlib import Path

import mlflow

from src.agent_client import AgentClient

FIXTURE_PATH = Path(__file__).parent.parent.parent / "fixtures" / "prompt_bank.json"
ACCURACY_GATE = 0.8  # regression threshold — fail the build below this


def _load_prompt_bank():
    return json.loads(FIXTURE_PATH.read_text())


def test_agent_accuracy_against_golden_prompt_bank():
    prompts = _load_prompt_bank()
    agent = AgentClient()

    db_path = Path.cwd() / "mlflow.db"
    mlflow.set_tracking_uri(f"sqlite:///{db_path}")
    mlflow.set_experiment("genai-dashboard-eval")

    with mlflow.start_run(run_name="prompt_bank_accuracy"):
        correct = 0
        for entry in prompts:
            response = agent.ask(entry["prompt"])
            is_correct = (
                not response.refused
                and response.sql is not None
                and all(kw in response.sql.lower() for kw in entry["expected_sql_keywords"])
            )
            correct += int(is_correct)
            mlflow.log_metric(f"correct__{entry['category']}_{entry['domain']}", int(is_correct))

        accuracy = correct / len(prompts)
        mlflow.log_metric("accuracy", accuracy)
        mlflow.log_param("prompt_count", len(prompts))
        mlflow.log_param("accuracy_gate", ACCURACY_GATE)

    agent.close()
    assert accuracy >= ACCURACY_GATE, f"Accuracy {accuracy:.0%} fell below the {ACCURACY_GATE:.0%} regression gate"
