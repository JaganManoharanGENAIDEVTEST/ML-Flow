"""
Validates the dashboard as a user would actually see it: correct number of
chart elements, and tooltip/table values matching the underlying data
exactly, so a display bug can't hide behind correct data.
"""
import pytest
from playwright.sync_api import sync_playwright

from src.agent_client import AgentClient
from src.powerbi_client import PowerBIClient


@pytest.fixture(scope="module")
def rendered_dashboard():
    agent = AgentClient()
    response = agent.ask("total transaction amount by branch")
    agent.close()

    pbi = PowerBIClient()
    path = pbi.render_dashboard(
        title="Total Transaction Amount by Branch",
        table=response.table,
        value_key="total_amount",
        label_key="branch",
    )
    return path, response.table


@pytest.fixture(scope="module")
def page():
    with sync_playwright() as p:
        browser = p.chromium.launch()
        pg = browser.new_page()
        yield pg
        browser.close()


def test_chart_renders_one_bar_per_branch(rendered_dashboard, page):
    path, table = rendered_dashboard
    page.goto(f"file://{path}")

    bars = page.locator(".bar")
    assert bars.count() == len(table), "Expected one bar per branch"


def test_tooltip_matches_underlying_data(rendered_dashboard, page):
    path, table = rendered_dashboard
    page.goto(f"file://{path}")

    bars = page.locator(".bar")
    for i, row in enumerate(table):
        tooltip = bars.nth(i).get_attribute("title")
        expected = f"{row['branch']}: {row['total_amount']}"
        assert tooltip == expected, f"Tooltip mismatch at bar {i}"


def test_table_values_match_agent_output(rendered_dashboard, page):
    path, table = rendered_dashboard
    page.goto(f"file://{path}")

    cell_texts = page.locator(".cell-total_amount").all_inner_texts()
    for row in table:
        assert str(row["total_amount"]) in cell_texts, "Table cell doesn't match agent data"
