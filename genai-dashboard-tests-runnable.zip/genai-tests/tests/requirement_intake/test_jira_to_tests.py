"""
Validates the requirement-intake loop: pull a Jira User Story, turn it into
test cases and NL prompts, and confirm the generated prompts actually run
end-to-end through the existing data layer — closing the loop from
requirement straight through to executable test coverage.
"""
from src.agent_client import AgentClient
from src.jira_client import JiraClient
from src.test_generator import generate_tests_from_story


def test_generates_test_cases_and_prompts_from_user_story():
    jira = JiraClient()
    story = jira.get_user_story("BANK-101")

    result = generate_tests_from_story(story)

    assert result["ticket"] == "BANK-101"
    assert len(result["test_cases"]) == len(story["acceptance_criteria"])
    assert all("id" in tc and "criterion" in tc and "test_type" in tc for tc in result["test_cases"])
    assert len(result["prompts"]) >= 1


def test_generated_prompt_runs_end_to_end_through_the_agent():
    jira = JiraClient()
    story = jira.get_user_story("BANK-101")
    generated = generate_tests_from_story(story)

    agent = AgentClient()
    response = agent.ask(generated["prompts"][0])
    agent.close()

    assert not response.refused, (
        f"Generated prompt could not be resolved by the agent: {generated['prompts'][0]!r}"
    )
    assert response.table, "Expected a non-empty result for the generated prompt"


def test_results_can_be_posted_back_to_jira(capsys):
    jira = JiraClient()
    jira.post_test_results_comment("BANK-101", "3/3 generated test cases passed.")
    captured = capsys.readouterr()
    assert "BANK-101" in captured.out
