# GenAI Dashboard Test Automation Framework

A **runnable** automation suite for an LLM-based application that converts
natural language prompts into Snowflake SQL, returns a result table, and
renders a Power BI dashboard.

Everything here works out of the box in **mock mode** — no Snowflake,
Power BI, or Jira credentials required — using an in-memory SQLite
database, a locally-rendered HTML dashboard, and local JSON fixtures. Flip
one setting (`FRAMEWORK_MODE=live`) and wire up the four `src/*_client.py`
files to point at your real services.

Verified: `python -m pytest -v` → **21 passed, 0 failed, 0 errors.**

## Layers

| # | Area                | Tool               | Location                    |
|---|----------------------|--------------------|------------------------------|
| 0 | Requirement Intake   | Pytest             | `tests/requirement_intake/`  |
| 1 | Data / SQL           | Pytest             | `tests/data/`                |
| 2 | Dashboard UI         | Playwright         | `tests/ui/`                  |
| 3 | Alerts & Streaming   | Pytest             | `tests/functional/`          |
| 4 | AI Output Quality    | MLflow             | `tests/eval/`                |

## Setup

```bash
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt
playwright install chromium
cp .env.example .env   # defaults to FRAMEWORK_MODE=mock — no edits needed to run
```

## Running

```bash
# everything
pytest -v

# one layer at a time
pytest tests/requirement_intake -v
pytest tests/data -v
pytest tests/ui -v
pytest tests/functional -v
pytest tests/eval -v

# HTML report
pytest --html=reports/report.html --self-contained-html

# view AI-quality trend across runs
mlflow ui --backend-store-uri sqlite:///mlflow.db
```

## What each layer actually does (in mock mode)

- **Requirement Intake** (`src/jira_client.py`, `src/test_generator.py`) —
  reads a User Story from `fixtures/jira_user_story.json`, drafts a test
  case per acceptance criterion, and derives NL prompts from the story
  summary. One of those generated prompts is then run straight through the
  agent to prove the loop is genuinely end-to-end, not just illustrative.
- **Data / SQL** (`src/agent_client.py`, `src/snowflake_client.py`) — the
  "agent" resolves known prompts to SQL via a deterministic lookup table
  (standing in for the real LLM) and runs it against an in-memory SQLite
  database seeded with sample Banking/Logistics/Healthcare data. Tests diff
  the agent's table against an independently-issued query against the same
  data, plus a set of adversarial prompts (SQL injection attempts,
  nonsense input) that must be safely refused.
- **Dashboard UI** (`src/powerbi_client.py`) — renders the agent's result
  table into a real, static HTML page (`mock_data/dashboard_template.html`)
  and drives it with Playwright: checks bar count, tooltip-vs-data match,
  and table-vs-agent-output match.
- **Alerts & Streaming** (`src/alerts.py`, `src/streaming.py`) — an
  in-process alert manager (threshold, delivery payload, de-duplication
  window) and an incremental-refresh simulator (no duplicate or missing
  rows across repeated refreshes).
- **AI Output Quality** (`tests/eval/test_llm_eval.py`) — runs the full
  `fixtures/prompt_bank.json` question set through the agent, scores
  keyword-level accuracy per prompt, and logs it to MLflow so a regression
  is visible run over run. Currently gated at 80% accuracy.

## Switching to live mode

1. Set `FRAMEWORK_MODE=live` in `.env`.
2. `pip install -r requirements-live.txt`.
3. Fill in the Snowflake / Power BI / Jira values in `.env`.
4. Replace the body of `AgentClient.ask()` (live branch) with a call to your
   actual agent API endpoint.
5. Replace `PowerBIClient.render_dashboard()` (live branch) with a call to
   the Power BI REST API, returning an embed URL instead of a local file
   path — then point the Playwright tests at that URL.
6. Implement `test_generator._generate_live()` with a real LLM call
   (Anthropic, OpenAI, etc.) if you want the requirement-intake layer to use
   actual language understanding instead of the rule-based mock generator.

Each of these live-mode branches already raises a clear `NotImplementedError`
or `RuntimeError` telling you exactly what to wire up, so nothing fails
silently if a step is skipped.

## Extending the prompt bank

Add new entries to `fixtures/prompt_bank.json` (used by both the data and
eval layers) and a matching SQL template to `PROMPT_SQL_MAP` in
`src/agent_client.py` as new question types come up in real usage.
