import json
import os
import pytest

from config import TEST_DATA_PATH, RESULTS_OUTPUT_PATH
from utils.data_loader import load_test_cases

# ---------------------------------------------------------------------------
# Test data fixtures - both API and UI suites read from the same CSV so a
# discrepancy between them is a real signal, not a data-drift artifact.
# ---------------------------------------------------------------------------

@pytest.fixture(scope="session")
def all_cases():
    return load_test_cases(TEST_DATA_PATH)


@pytest.fixture(scope="session")
def functional_cases():
    return load_test_cases(TEST_DATA_PATH, test_type="functional")


@pytest.fixture(scope="session")
def negative_cases():
    return load_test_cases(TEST_DATA_PATH, test_type="negative")


@pytest.fixture(scope="session")
def boundary_cases():
    return load_test_cases(TEST_DATA_PATH, test_type="boundary")


# ---------------------------------------------------------------------------
# Results collection - every test appends a result row here.
# log_eval_to_mlflow.py reads this file to compute accuracy + confusion matrix,
# and it's also handy raw evidence to attach to Allure.
# ---------------------------------------------------------------------------
_results = []


def record_result(test_id, prompt, expected, actual, layer, passed, notes=""):
    _results.append({
        "test_id": test_id,
        "prompt": prompt,
        "expected_chart_type": expected,
        "actual_chart_type": actual,
        "layer": layer,          # "api" or "ui"
        "passed": passed,
        "notes": notes,
    })


@pytest.fixture
def result_recorder():
    return record_result


def pytest_sessionfinish(session, exitstatus):
    os.makedirs(os.path.dirname(RESULTS_OUTPUT_PATH), exist_ok=True)
    with open(RESULTS_OUTPUT_PATH, "w", encoding="utf-8") as f:
        json.dump(_results, f, indent=2)
    print(f"\n[results] wrote {len(_results)} test results -> {RESULTS_OUTPUT_PATH}")
