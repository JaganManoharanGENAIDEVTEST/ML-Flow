"""
Central config for the chart recommender test framework.
Everything env-driven so this runs unchanged across DEV/UAT/PROD.
"""
import os

# API under test
API_BASE_URL = os.getenv("CHART_API_BASE_URL", "https://your-genai-app/api")
CHART_RECOMMEND_ENDPOINT = f"{API_BASE_URL}/chart-recommend"
API_TIMEOUT_SECONDS = int(os.getenv("API_TIMEOUT_SECONDS", "15"))

# Power BI / dashboard UI under test
DASHBOARD_URL = os.getenv("DASHBOARD_URL", "https://your-powerbi-dashboard-url")
UI_TIMEOUT_MS = int(os.getenv("UI_TIMEOUT_MS", "15000"))
HEADLESS = os.getenv("HEADLESS", "true").lower() == "true"

# Selectors - update these once you inspect the actual app via DevTools
PROMPT_INPUT_SELECTOR = os.getenv("PROMPT_INPUT_SELECTOR", "#prompt-input")
SUBMIT_BUTTON_SELECTOR = os.getenv("SUBMIT_BUTTON_SELECTOR", "#submit-btn")
CHART_CONTAINER_SELECTOR = os.getenv("CHART_CONTAINER_SELECTOR", ".visual-container")
CHART_TYPE_ATTRIBUTE = os.getenv("CHART_TYPE_ATTRIBUTE", "data-chart-type")

# Test data
TEST_DATA_PATH = os.getenv(
    "TEST_DATA_PATH",
    os.path.join(os.path.dirname(__file__), "data", "test_cases.csv"),
)

# Results output (consumed by utils/log_eval_to_mlflow.py)
RESULTS_OUTPUT_PATH = os.getenv(
    "RESULTS_OUTPUT_PATH",
    os.path.join(os.path.dirname(__file__), "results", "results.json"),
)
