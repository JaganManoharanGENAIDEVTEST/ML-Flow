# Chart Recommender Test Framework

Automated validation for the LLM auto chart recommender - given a natural
language prompt, the app should pick the right chart type (bar, column,
line, pie, scatter, etc.) for the Power BI dashboard.

Two independent validation layers run against the **same** prompt dataset:

- **API layer** (`tests/test_chart_type_api.py`) - calls the recommendation
  endpoint directly, asserts the JSON `chartType` field. Fast, deterministic.
- **UI layer** (`tests/test_chart_type_ui.py`) - drives the actual dashboard
  with Playwright and inspects what got rendered. Catches mapping/rendering
  bugs the API layer can't see.
- **Cross-layer check** (`test_api_ui_consistency`) - flags any case where
  API and UI disagree, which isolates the bug to rendering rather than the
  LLM's reasoning.

## Setup

```bash
pip install -r requirements.txt
playwright install chromium

cp .env.example .env
# edit .env: set CHART_API_BASE_URL, DASHBOARD_URL, and the four selectors
# (inspect the real app in DevTools first - see step 1 below)
export $(cat .env | xargs)
```

## Before you run anything: find your selectors

Open the dashboard in a browser, submit a prompt manually, open DevTools ->
Elements, and find:
1. The input field the prompt is typed into -> `PROMPT_INPUT_SELECTOR`
2. The submit button -> `SUBMIT_BUTTON_SELECTOR`
3. The element Power BI wraps the rendered visual in -> `CHART_CONTAINER_SELECTOR`
4. Whatever attribute/class on that element encodes the chart type (this is
   the part that varies most by app - might be a `data-*` attribute, an SVG
   class, or you may need to infer it from the visual's DOM structure) ->
   `CHART_TYPE_ATTRIBUTE`

If there's no clean attribute, you'll need a small helper that maps DOM
structure (e.g. presence of `.barChart` vs `.lineChart` container classes)
to a chart-type string - swap that logic into `_submit_prompt_and_get_rendered_type`
in `tests/test_chart_type_ui.py`.

## Run

```bash
# everything
pytest

# just the fast API layer (good for every commit / CI)
pytest -m api

# just functional cases, skip negative/boundary
pytest -m "api and functional"

# UI layer only (slower, run nightly or pre-release)
pytest -m ui

# with Allure
pytest --alluredir=allure-results
allure serve allure-results
```

## Log to MLflow

After a run, `results/results.json` has every test's expected vs actual
chart type. Push accuracy + a confusion matrix to MLflow:

```bash
python utils/log_eval_to_mlflow.py --run-name "chart-recommender-baseline"
```

Use the same MLflow experiment naming convention as the prompt-to-SQL eval
framework so both show up together when comparing model/prompt versions.

## Extending the dataset

Add rows to `data/test_cases.csv`. Columns:

| Column | Meaning |
|---|---|
| `test_id` | Unique ID |
| `user_prompt` | The natural language prompt |
| `data_context` | Columns available to the model (documentation only) |
| `expected_chart_type` | Ground truth from the oracle |
| `acceptable_alternates` | Pipe-separated (`bar\|column`) - use when more than one chart type is genuinely valid |
| `test_type` | `functional` \| `negative` \| `boundary` |
| `ambiguity_flag` | `Yes`/`No` - vague prompts get routed to the negative-suite tolerance logic |
| `priority` | High/Medium/Low |
| `notes` | Why this case exists |

No code changes needed to add new functional cases - the suites pick up
new rows automatically. New `negative` or `boundary` behavior may need a
small tweak to the relevant test function's assertion logic.

## Project layout

```
chart_recommender_tests/
├── conftest.py                    # fixtures, results collection
├── config.py                      # all env-driven config
├── pytest.ini
├── requirements.txt
├── .env.example
├── data/
│   └── test_cases.csv             # the single source of truth dataset
├── tests/
│   ├── test_chart_type_api.py     # Layer 1
│   └── test_chart_type_ui.py      # Layer 2 + cross-layer consistency
├── utils/
│   ├── data_loader.py             # CSV -> ChartTestCase objects
│   └── log_eval_to_mlflow.py      # results.json -> MLflow metrics
└── results/
    ├── results.json               # written after every pytest run
    └── screenshots/                # UI failure evidence
```
