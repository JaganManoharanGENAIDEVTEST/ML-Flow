"""
Loads the prompt -> expected-chart-type test dataset and hands back
plain dicts, ready to feed into pytest.mark.parametrize.

Keeping this separate from the tests means the SAME dataset drives
both the API layer and UI layer suites - one source of truth.
"""
import csv
from dataclasses import dataclass, field


@dataclass
class ChartTestCase:
    test_id: str
    user_prompt: str
    data_context: str
    expected_chart_type: str
    acceptable_alternates: list = field(default_factory=list)
    test_type: str = "functional"      # functional | negative | boundary
    ambiguity_flag: bool = False
    priority: str = "Medium"
    notes: str = ""

    def matches(self, actual_chart_type):
        """True if actual matches expected OR any documented acceptable alternate."""
        if actual_chart_type is None:
            return False
        actual = actual_chart_type.strip().lower()
        valid = {self.expected_chart_type.strip().lower()} if self.expected_chart_type else set()
        valid |= {a.strip().lower() for a in self.acceptable_alternates if a.strip()}
        return actual in valid


def load_test_cases(csv_path, test_type=None, include_ambiguous=True):
    """
    Read the dataset CSV and return a list of ChartTestCase.

    test_type: filter to "functional" | "negative" | "boundary" | None (all)
    include_ambiguous: set False to exclude ambiguity_flag=Yes rows
                        (useful when you only want strict, deterministic assertions)
    """
    cases = []
    with open(csv_path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            is_ambiguous = row["ambiguity_flag"].strip().lower() == "yes"
            if not include_ambiguous and is_ambiguous:
                continue
            if test_type and row["test_type"].strip().lower() != test_type.lower():
                continue

            alternates_raw = row.get("acceptable_alternates", "") or ""
            cases.append(ChartTestCase(
                test_id=row["test_id"],
                user_prompt=row["user_prompt"],
                data_context=row["data_context"],
                expected_chart_type=row["expected_chart_type"],
                acceptable_alternates=[a for a in alternates_raw.split("|") if a],
                test_type=row["test_type"],
                ambiguity_flag=is_ambiguous,
                priority=row["priority"],
                notes=row["notes"],
            ))
    return cases
