"""
Reads results/results.json (written by conftest.py's pytest_sessionfinish)
and logs accuracy + a confusion matrix to MLflow - same pattern as the
prompt-to-SQL eval framework, so both live in one MLflow experiment for
side-by-side comparison across model/prompt versions.

Run after the pytest suite:
    pytest
    python utils/log_eval_to_mlflow.py --run-name "chart-recommender-v1"
"""
import argparse
import json
import os
from collections import defaultdict

import mlflow

from config import RESULTS_OUTPUT_PATH


def load_results(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def compute_metrics(results):
    total = len(results)
    passed = sum(1 for r in results if r["passed"])
    accuracy = passed / total if total else 0.0

    # confusion matrix: expected -> {actual: count}, only for cases with a defined expectation
    confusion = defaultdict(lambda: defaultdict(int))
    for r in results:
        expected = (r["expected_chart_type"] or "").strip().lower()
        actual = (r["actual_chart_type"] or "").strip().lower()
        if expected and expected not in ("clarification-or-none", "4xx-graceful-error"):
            confusion[expected][actual] += 1

    per_layer = defaultdict(lambda: {"total": 0, "passed": 0})
    for r in results:
        per_layer[r["layer"]]["total"] += 1
        per_layer[r["layer"]]["passed"] += int(r["passed"])

    return {
        "total": total,
        "passed": passed,
        "failed": total - passed,
        "accuracy": accuracy,
        "confusion": {k: dict(v) for k, v in confusion.items()},
        "per_layer": dict(per_layer),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-name", default="chart-recommender-eval")
    parser.add_argument("--experiment", default="genai-chart-recommender")
    parser.add_argument("--results-path", default=RESULTS_OUTPUT_PATH)
    args = parser.parse_args()

    if not os.path.exists(args.results_path):
        raise SystemExit(f"No results file at {args.results_path} - run pytest first.")

    results = load_results(args.results_path)
    metrics = compute_metrics(results)

    mlflow.set_experiment(args.experiment)
    with mlflow.start_run(run_name=args.run_name):
        mlflow.log_metric("accuracy", metrics["accuracy"])
        mlflow.log_metric("total_cases", metrics["total"])
        mlflow.log_metric("passed", metrics["passed"])
        mlflow.log_metric("failed", metrics["failed"])

        for layer, stats in metrics["per_layer"].items():
            layer_acc = stats["passed"] / stats["total"] if stats["total"] else 0
            mlflow.log_metric(f"accuracy_{layer}", layer_acc)

        # log full results + confusion matrix as artifacts for drill-down
        artifact_dir = "eval_artifacts"
        os.makedirs(artifact_dir, exist_ok=True)
        with open(os.path.join(artifact_dir, "results.json"), "w") as f:
            json.dump(results, f, indent=2)
        with open(os.path.join(artifact_dir, "confusion_matrix.json"), "w") as f:
            json.dump(metrics["confusion"], f, indent=2)
        mlflow.log_artifacts(artifact_dir)

        print(f"Logged run '{args.run_name}' to experiment '{args.experiment}'")
        print(f"Accuracy: {metrics['accuracy']:.2%} ({metrics['passed']}/{metrics['total']})")
        for layer, stats in metrics["per_layer"].items():
            print(f"  {layer}: {stats['passed']}/{stats['total']}")


if __name__ == "__main__":
    main()
