"""
Layer 2: UI/rendering validation via Playwright.

Even if the API returns the right chartType, Power BI can render the
wrong visual due to a mapping bug between the API response and the
report's visual config. This suite drives the actual dashboard and
inspects what got rendered.

Update the selectors in config.py once you've inspected the real app
via browser DevTools (Elements tab -> find the container Power BI
wraps each visual in, and whatever attribute/class encodes its type).
"""
import pytest
from playwright.sync_api import sync_playwright

from config import (
    DASHBOARD_URL, UI_TIMEOUT_MS, HEADLESS,
    PROMPT_INPUT_SELECTOR, SUBMIT_BUTTON_SELECTOR,
    CHART_CONTAINER_SELECTOR, CHART_TYPE_ATTRIBUTE,
    TEST_DATA_PATH,
)
from utils.data_loader import load_test_cases, ChartTestCase


def _ids(case: ChartTestCase):
    return f"{case.test_id}-{case.user_prompt[:30]}"


FUNCTIONAL = load_test_cases(TEST_DATA_PATH, test_type="functional", include_ambiguous=False)


@pytest.fixture(scope="session")
def browser():
    with sync_playwright() as p:
        b = p.chromium.launch(headless=HEADLESS)
        yield b
        b.close()


def _submit_prompt_and_get_rendered_type(page, prompt: str) -> str:
    page.goto(DASHBOARD_URL)
    page.fill(PROMPT_INPUT_SELECTOR, prompt)
    page.click(SUBMIT_BUTTON_SELECTOR)
    page.wait_for_selector(CHART_CONTAINER_SELECTOR, timeout=UI_TIMEOUT_MS)
    return page.locator(CHART_CONTAINER_SELECTOR).get_attribute(CHART_TYPE_ATTRIBUTE)


@pytest.mark.ui
@pytest.mark.functional
@pytest.mark.parametrize("case", FUNCTIONAL, ids=_ids)
def test_chart_type_ui_functional(case, browser, result_recorder):
    page = browser.new_page()
    try:
        rendered_type = _submit_prompt_and_get_rendered_type(page, case.user_prompt)
        passed = case.matches(rendered_type)
        result_recorder(case.test_id, case.user_prompt, case.expected_chart_type, rendered_type, "ui", passed, case.notes)

        if not passed:
            # capture evidence on failure - attach this path to your Allure report
            page.screenshot(path=f"results/screenshots/{case.test_id}_failure.png")

        assert passed, (
            f"{case.test_id} | prompt: '{case.user_prompt}' | "
            f"expected rendered: {case.expected_chart_type} | got: {rendered_type}"
        )
    finally:
        page.close()


@pytest.mark.ui
@pytest.mark.functional
def test_api_ui_consistency(all_cases, browser):
    """
    Cross-layer check: for each functional case, does the UI-rendered type
    match what the API returned? A mismatch here isolates the bug to the
    Power BI mapping/rendering layer rather than the LLM's reasoning -
    a distinction your bug reports should always make explicit.
    """
    import requests
    from config import CHART_RECOMMEND_ENDPOINT, API_TIMEOUT_SECONDS

    mismatches = []
    for case in [c for c in all_cases if c.test_type == "functional" and not c.ambiguity_flag]:
        api_resp = requests.post(
            CHART_RECOMMEND_ENDPOINT, json={"prompt": case.user_prompt}, timeout=API_TIMEOUT_SECONDS
        )
        api_chart = api_resp.json().get("chartType") if api_resp.status_code == 200 else None

        page = browser.new_page()
        try:
            ui_chart = _submit_prompt_and_get_rendered_type(page, case.user_prompt)
        finally:
            page.close()

        if (api_chart or "").strip().lower() != (ui_chart or "").strip().lower():
            mismatches.append((case.test_id, api_chart, ui_chart))

    assert not mismatches, f"API/UI chart-type mismatches (rendering bug, not LLM bug): {mismatches}"
