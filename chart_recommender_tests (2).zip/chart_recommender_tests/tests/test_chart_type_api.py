"""
Layer 1: API/metadata validation.

Calls the chart-recommendation endpoint directly and asserts the returned
chartType against the oracle (with documented acceptable alternates).
Fast and deterministic - run this on every commit.
"""
import pytest
import requests

from config import CHART_RECOMMEND_ENDPOINT, API_TIMEOUT_SECONDS
from utils.data_loader import load_test_cases, ChartTestCase
from config import TEST_DATA_PATH


def _ids(case: ChartTestCase):
    return f"{case.test_id}-{case.user_prompt[:30]}"


FUNCTIONAL = load_test_cases(TEST_DATA_PATH, test_type="functional", include_ambiguous=False)
BOUNDARY = load_test_cases(TEST_DATA_PATH, test_type="boundary")
NEGATIVE = load_test_cases(TEST_DATA_PATH, test_type="negative")


def _call_chart_api(prompt: str) -> requests.Response:
    return requests.post(
        CHART_RECOMMEND_ENDPOINT,
        json={"prompt": prompt},
        timeout=API_TIMEOUT_SECONDS,
    )


@pytest.mark.api
@pytest.mark.functional
@pytest.mark.parametrize("case", FUNCTIONAL, ids=_ids)
def test_chart_type_api_functional(case, result_recorder):
    resp = _call_chart_api(case.user_prompt)
    assert resp.status_code == 200, f"{case.test_id}: expected 200, got {resp.status_code}"

    actual = resp.json().get("chartType")
    passed = case.matches(actual)
    result_recorder(case.test_id, case.user_prompt, case.expected_chart_type, actual, "api", passed, case.notes)

    assert passed, (
        f"{case.test_id} | prompt: '{case.user_prompt}' | "
        f"expected: {case.expected_chart_type} (alt: {case.acceptable_alternates}) | got: {actual}"
    )


@pytest.mark.api
@pytest.mark.boundary
@pytest.mark.parametrize("case", BOUNDARY, ids=_ids)
def test_chart_type_api_boundary(case, result_recorder):
    """
    Boundary cases check the LLM doesn't misuse chart types at cardinality
    extremes - e.g. picking pie for 50 categories, or being unnecessarily
    strict when 2-3 categories make either bar or pie valid.
    """
    resp = _call_chart_api(case.user_prompt)
    assert resp.status_code == 200

    actual = resp.json().get("chartType")
    passed = case.matches(actual)
    result_recorder(case.test_id, case.user_prompt, case.expected_chart_type, actual, "api", passed, case.notes)

    assert passed, (
        f"{case.test_id} | {case.notes} | expected: {case.expected_chart_type} | got: {actual}"
    )


@pytest.mark.api
@pytest.mark.negative
@pytest.mark.parametrize("case", NEGATIVE, ids=_ids)
def test_chart_type_api_negative(case, result_recorder):
    """
    Negative/ambiguous prompts should NOT produce a confidently wrong chart
    type. Acceptable outcomes: a clarification response, a documented
    default, or a graceful 4xx - never a fabricated chart type with no
    basis in the prompt/data. Adjust the response-shape checks below once
    you know your app's actual contract for these cases.
    """
    resp = _call_chart_api(case.user_prompt)

    # The exact contract here depends on your app - this checks for EITHER
    # a clarification signal OR a controlled error, not a silent 200 with
    # a random chart type.
    if resp.status_code == 200:
        body = resp.json()
        actual = body.get("chartType")
        needs_clarification = body.get("needsClarification", False)
        passed = needs_clarification or actual is None
        result_recorder(case.test_id, case.user_prompt, "clarification-or-none", actual, "api", passed, case.notes)
        assert passed, (
            f"{case.test_id} | vague/malformed prompt returned a confident chartType "
            f"'{actual}' with no clarification flag - likely hallucination. {case.notes}"
        )
    else:
        result_recorder(case.test_id, case.user_prompt, "4xx-graceful-error", f"HTTP {resp.status_code}", "api", True, case.notes)
        assert resp.status_code in (400, 422), f"{case.test_id}: unexpected status {resp.status_code}"
